import {
  require_react
} from "./chunk-GF4N4SDM.js";
export default require_react();
//# sourceMappingURL=react.js.map
